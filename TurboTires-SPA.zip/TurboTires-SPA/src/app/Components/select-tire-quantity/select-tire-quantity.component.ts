import { Component, OnInit } from '@angular/core';
import {PlaceOrderForTireService} from "../../Services/place-order-for-tire.service";

@Component({
  selector: 'app-select-tire-quantity',
  templateUrl: './select-tire-quantity.component.html',
  styleUrls: ['./select-tire-quantity.component.css']
})
export class SelectTireQuantityComponent implements OnInit {

  state: SelectTireQuantityComponentState;

  constructor(private placeOrderForTireService: PlaceOrderForTireService) {
    this.state = new SelectTireQuantityComponentState();  }

  ngOnInit() {
    this.placeOrderForTireService.setSelectTireQuantityComponent(this);
  }

  getQuantityList(event, qty_value) {
    this.placeOrderForTireService.getPlaceOrderForTireComponent().state.tireQtyList.push(qty_value);
  }
}

  export class SelectTireQuantityComponentState{
  tireQty = [
    {displayValue: '1', value: 1},
    {displayValue: '2', value: 2},
    {displayValue: '3', value: 3},
    {displayValue: '4', value: 4},
    {displayValue: '5', value: 5}
  ]
}

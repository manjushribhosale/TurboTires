import { TestBed, inject } from '@angular/core/testing';

import { PlaceOrderForTireService } from './place-order-for-tire.service';

describe('PlaceOrderForTireService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PlaceOrderForTireService]
    });
  });

  it('should be created', inject([PlaceOrderForTireService], (service: PlaceOrderForTireService) => {
    expect(service).toBeTruthy();
  }));
});

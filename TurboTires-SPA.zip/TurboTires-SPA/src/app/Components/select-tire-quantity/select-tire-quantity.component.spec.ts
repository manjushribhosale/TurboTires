import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectTireQuantityComponent } from './select-tire-quantity.component';

describe('SelectTireQuantityComponent', () => {
  let component: SelectTireQuantityComponent;
  let fixture: ComponentFixture<SelectTireQuantityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectTireQuantityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectTireQuantityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

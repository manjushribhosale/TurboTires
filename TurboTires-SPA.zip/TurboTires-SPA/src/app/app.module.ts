import { BrowserModule } from '@angular/platform-browser';
import {CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA} from '@angular/core';
import { FormsModule } from '@angular/forms';
import {HttpClientModule} from "@angular/common/http";
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {FlexLayoutModule} from "@angular/flex-layout";
import {
  MatCheckboxModule,
  MatMenuModule,
  MatSidenavModule,
  MatToolbarModule,
  MatButtonModule,
  MatIconModule,
  MatListModule,
  MatInputModule,
  MatFormFieldModule,
  MatSelectModule,
  MatCardModule,
  MatRadioModule,
  MatOptionModule,
  MatSliderModule,
  MatDialogModule,
  MatGridListModule,
  MatExpansionModule
} from '@angular/material';
import { PlaceOrderForTireComponent } from './Pages/place-order-for-tire/place-order-for-tire.component';
import { SelectTireQuantityComponent } from './Components/select-tire-quantity/select-tire-quantity.component';

@NgModule({
  declarations: [
    AppComponent,
    PlaceOrderForTireComponent,
    SelectTireQuantityComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    BrowserModule,
    FormsModule,
    MatFormFieldModule,
    MatMenuModule,
    MatSidenavModule,
    MatToolbarModule,
    MatButtonModule,
    MatIconModule,
    MatListModule,
    MatInputModule,
    MatCardModule,
    MatRadioModule,
    MatOptionModule,
    MatSelectModule,
    MatSliderModule,
    FlexLayoutModule,
    HttpClientModule,
    MatDialogModule,
    MatGridListModule,
    MatExpansionModule,
    MatCheckboxModule
  ],
  providers: [],
  bootstrap: [AppComponent],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA,
    NO_ERRORS_SCHEMA
  ],
})
export class AppModule { }

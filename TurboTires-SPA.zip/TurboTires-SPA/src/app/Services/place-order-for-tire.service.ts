import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import {SelectTireQuantityComponent} from "../Components/select-tire-quantity/select-tire-quantity.component";
import {PlaceOrderForTireComponent} from "../Pages/place-order-for-tire/place-order-for-tire.component";

@Injectable({
  providedIn: 'root'
})
export class PlaceOrderForTireService {

  url : string = 'http://localhost:8090';
  tireData = [];

  constructor(private http: HttpClient) { }

  getURL(){
    return this.url;
  }

  getTireDetails(){
    let url = this.getURL() + "/getTireDetails";
    this.http.get(url).subscribe(tireData => {
      console.log("Tire Data in Turbo Service ----- ", tireData);
    });
    return this.tireData;
  }

  selectTireQuantityComponent: SelectTireQuantityComponent;

  getSelectTireQuantityComponent() {
    return this.selectTireQuantityComponent;
  }

  setSelectTireQuantityComponent(navBar: SelectTireQuantityComponent) {
    this.selectTireQuantityComponent = navBar;
  }

  placeOrderForTireComponent: PlaceOrderForTireComponent;

  getPlaceOrderForTireComponent() {
    return this.placeOrderForTireComponent;
  }

  setPlaceOrderForTireComponent(placeOrderForTireComponent: PlaceOrderForTireComponent) {
    this.placeOrderForTireComponent = placeOrderForTireComponent;
  }
}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlaceOrderForTireComponent } from './place-order-for-tire.component';

describe('PlaceOrderForTireComponent', () => {
  let component: PlaceOrderForTireComponent;
  let fixture: ComponentFixture<PlaceOrderForTireComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlaceOrderForTireComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlaceOrderForTireComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

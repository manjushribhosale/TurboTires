import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { PlaceOrderForTireService } from '../../Services/place-order-for-tire.service'

@Component({
  selector: 'app-place-order-for-tire',
  templateUrl: './place-order-for-tire.component.html',
  styleUrls: ['./place-order-for-tire.component.css']
})
export class PlaceOrderForTireComponent implements OnInit {

  state: PlaceOrderForTireComponentState;

  constructor(private placeOrderForTireService: PlaceOrderForTireService,
              private http: HttpClient) {
    this.state = new PlaceOrderForTireComponentState();
    this.placeOrderForTireService.setPlaceOrderForTireComponent(this);
  }

  ngOnInit() {
    this.http.get('http://localhost:8090/getTireDetails').subscribe(tireData => {
      this.state.tireInfo =  tireData;
      console.log("Tire Info", this.state.tireInfo);
    },error => {
      console.log("Something went wrong!", error);
    });
  }

  calculateTotalOrder(){
      this.http.post("http://localhost:8090/calculateTotalOrder" +
        "?tire_price=" + this.state.selectedTiresPrice +
        "&tire_qty=" + this.state.tireQtyList, "json").subscribe(orderTotal => {
        this.state.orderTotal = orderTotal;
      },error => {
        console.log("Something went wrong!", error);
      });
  }

  getTireDetails(event, tire_brand, tire_price){
    this.state.selectedTiresBrand.push(tire_brand.toString());
    this.state.selectedTiresPrice.push(tire_price.toString());
  }

  placeTiresOrder(){
    this.state.message = "Thank you for your order!";
  }
}

export class PlaceOrderForTireComponentState{
  tireInfo : any = [];
  selectedTiresBrand: any = [];
  selectedTiresPrice: any = [];
  tireQtyList: any = [];
  orderTotal: any = 0;
  message: string ="";
}
